package tempFuture;

public class ToxicPlant {
}
