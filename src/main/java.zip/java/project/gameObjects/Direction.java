package project.gameObjects;

public enum Direction {
    Right,
    Left,
    Up,
    Down,
    Still,
}
