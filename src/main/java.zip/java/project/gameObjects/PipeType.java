package project.gameObjects;

public enum PipeType {
    Short,
    Medium,
    Long,
}
