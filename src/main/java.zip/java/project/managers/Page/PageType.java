package project.managers.Page;

public enum PageType {
    StartPage,
    HomePage,
    SignupPage,
    LoginPage,
    HardnessPage,
    ProfilePage,
    ShopPage,
    HistoryPage,
}
