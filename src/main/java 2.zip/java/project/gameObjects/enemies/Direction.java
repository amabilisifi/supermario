package project.gameObjects.enemies;

public enum Direction {
    Right,
    Left,
    Up,
    Down,
}
