package project.gameObjects;

public enum ItemType {
    Coin,
    MagicalStar,
    MagicalMushroom,
    MagicalFlower,
}
