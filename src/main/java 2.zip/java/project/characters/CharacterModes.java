package project.characters;

public enum CharacterModes {
    Mini, // height 1 block - loses heart
    Mega, // its normal // height 2 block - can break blocks - turns to mini mario
    Fiery, // height 2 block - can break blocks - turns to mega mario - can shoot
}
